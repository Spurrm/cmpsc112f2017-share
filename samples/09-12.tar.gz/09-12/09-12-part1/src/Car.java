package com.oops;
public class Car{
  String model;
  String color;
  Boolean doneService = false;


}
