package com.oops;
public abstract class Services{
  // function definition
  public abstract Car serviceCar(Car c);
  public void doNothing(){
    System.out.println("#do nothing....");
  }
}
