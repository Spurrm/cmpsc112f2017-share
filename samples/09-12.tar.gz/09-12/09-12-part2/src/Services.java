package com.oops;
public interface Services{
  public abstract Car serviceCar(Car c);
  // here you would have strictly function defintiions....
}
